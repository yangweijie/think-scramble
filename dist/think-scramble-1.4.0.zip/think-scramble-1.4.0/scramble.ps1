#!/usr/bin/env pwsh
php "$PSScriptRoot/scramble.phar" @args
